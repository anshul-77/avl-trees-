// C program to insert a node in AVL tree
#include <stdio.h>
#include <stdlib.h>

// An AVL tree node
struct Node
{
	int key;
	struct Node *left;
	struct Node *right;
	int height;
};

int height(struct Node *N);

// A utility function to get maximum of two integers
int max(int a, int b)
{
	return (a > b) ? a : b;
}

/* Helper function that allocates a new node with the given key and
	NULL left and right pointers. */
struct Node *newNode(int key)
{
	struct Node *node = (struct Node *)malloc(sizeof(struct Node));
	node->key = key;
	node->left = NULL;
	node->right = NULL;
	node->height = 1; // new node is initially added at leaf
	return (node);
}

// A utility function to right rotate subtree rooted with y
// See the diagram given above.
struct Node *rightRotate(struct Node *y)
{
	struct Node *x = y->left;
	struct Node *T2 = x->right;

	// Perform rotation
	x->right = y;
	y->left = T2;

	// Update heights
	y->height = max(height(y->left), height(y->right)) + 1;
	x->height = max(height(x->left), height(x->right)) + 1;

	// Return new root
	return x;
}

// A utility function to left rotate subtree rooted with x
// See the diagram given above.
struct Node *leftRotate(struct Node *x)
{
	struct Node *y = x->right;
	struct Node *T2 = y->left;

	// Perform rotation
	y->left = x;
	x->right = T2;

	// Update heights
	x->height = max(height(x->left), height(x->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	// Return new root
	return y;
}

// Get Balance factor of node N
int getBalance(struct Node *N)
{
	if (N == NULL)
		return 0;
	return height(N->left) - height(N->right);
}

// A utility function to get the height of the tree
int height(struct Node *N)
{
	if (N == NULL)
		return 0;
	return N->height;
}

// Recursive function to insert a key in the subtree rooted
// with node and returns the new root of the subtree.
struct Node *insert(struct Node *node, int key)
{
	/* 1. Perform the normal BST insertion */
	if (node == NULL)
		return (newNode(key));

	if (key < node->key)
		node->left = insert(node->left, key);
	else if (key > node->key)
		node->right = insert(node->right, key);
	else // Equal keys are not allowed in BST
		return node;

	/* 2. Update height of this ancestor node */
	node->height = 1 + max(height(node->left), height(node->right));

	/* 3. Get the balance factor of this ancestor
		node to check whether this node became
		unbalanced */
	int balance = getBalance(node);

	// If this node becomes unbalanced, then
	// there are 4 cases

	// Left Left Case
	if (balance > 1 && key < node->left->key)
		return rightRotate(node);

	// Right Right Case
	if (balance < -1 && key > node->right->key)
		return leftRotate(node);

	// Left Right Case
	if (balance > 1 && key > node->left->key)
	{	
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}

	// Right Left Case
	if (balance < -1 && key < node->right->key)
	{
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}

	/* return the (unchanged) node pointer */
	return node;
}

// A utility function to print preorder traversal
// of the tree.
// The function also prints height of every node
void preOrder(struct Node *root)
{
	if (root != NULL)
	{
		printf("%d\t", root->key);
		preOrder(root->left);
		preOrder(root->right);
	}
}

void inorder(struct Node *st)
{
	if (st == NULL)
		return;
	inorder(st->left);
	printf("%d\t", st->key);
	inorder(st->right);
}

/* Driver program to test above function*/
int main()
{
	struct Node *root = NULL;

	/* Constructing tree given in the above figure */
	root = insert(root, 907);
	root = insert(root, 808);
	root = insert(root, 856);
	root = insert(root, 987);
	root = insert(root, 985);
	root = insert(root, 864);

	/* The constructed AVL Tree would be
			 30
			/ \
		  20   40
		/ 	\	\
	   10 	25  50
	*/

	inorder(root);
	printf("\n");
	preOrder(root);

	return 0;
}




/*--------------------------------------------------------------------------------------------------------------*/


#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<string.h>

// version 1.0

#define N 20
#define MLC (USER *)malloc(sizeof(USER))

/*--------------------------------------------------------------------------------------*/

typedef struct Node3
{
	int user_id ;
	char name[N/2];
	char area[N];
	long long int phone_no;
	char prevOrder[N*4];
	int height ;
	struct Node3 * left ;
	struct Node3 * right ;
}USER;

USER * root ;

/*--------------------------------------------------------------------------------------*/

int NodeHeight( USER * temp );
void createUserTree();
int max(int a, int b);
void insertUserNode(USER* st, USER* temp);
USER * performLLRotation(USER * temp);
USER * performLRRotation(USER * temp);
USER * performRLRotation(USER * temp);
USER * performRRRotation(USER * temp);
void preorderUser(USER * head);
int BalanceFactor(USER * temp);

/*--------------------------------------------------------------------------------------*/

void createUserTree()
{
	FILE* ptr = fopen("D:\\COMPUTER PROGRAMMING\\DS PROJECTS\\UsersList.txt", "a+");
	char buffer[400] ;
	USER * temp ;
	int head = 1 , i; 
	char k[10];
	while(fgets(buffer,200,ptr))
	{
		int ct = 0 ;
		char *tok ;
		tok = strtok(buffer,",") ;
		temp = MLC ;
		temp->right = NULL ;
		temp->left = NULL ; 
		temp->height = 1 ;
		char * ptr ;
		while( tok != NULL )
		{
			//printf("%s\t",tok);
			fflush(stdin);
			switch(ct)
			{
				case 0: 
					temp->user_id = atoi(tok); 
					break;
				case 1:
					strcpy( temp->name , tok );
					break;
				case 2:
					strcpy( temp->area , tok );
					break;
				case 3:
					temp->phone_no = atoll(tok);
					break;
				case 4:
					strcpy( temp->prevOrder , tok );
					break;
				default: ct = 0 ;
			}
			ct++ ;
			tok = strtok(NULL,",");
		};
		if(head == 1)
		{
			root = MLC ;
			strcpy(root->name, temp->name);
			root->user_id = temp->user_id;
			strcpy(root->area, temp->area);
			root->phone_no = temp->phone_no;
			strcpy(root->prevOrder, temp->prevOrder);
			root->left = NULL ;
			root->right = NULL ;
			root->height = 1 ;
			root = insertUserNode(temp);
		}
		else
		{
			root = insertUserNode(temp);
			preorderUser(root);
			printf("\n");
		}
		head = 0 ;
	};
	fclose(ptr);
}
/*--------------------------------------------------------------------------------------*/
USER *insert(USER *node)
{
	/* 1. Perform the normal BST insertion */
	if (node == NULL)
		return (newNode(key));

	if (key < node->key)
		node->left = insert(node->left, key);
	else if (key > node->key)
		node->right = insert(node->right, key);
	else // Equal keys are not allowed in BST
		return node;

	/* 2. Update height of this ancestor node */
	node->height = 1 + max(height(node->left), height(node->right));

	/* 3. Get the balance factor of this ancestor
		node to check whether this node became
		unbalanced */
	int balance = getBalance(node);

	// If this node becomes unbalanced, then
	// there are 4 cases

	// Left Left Case
	if (balance > 1 && key < node->left->key)
		return rightRotate(node);

	// Right Right Case
	if (balance < -1 && key > node->right->key)
		return leftRotate(node);

	// Left Right Case
	if (balance > 1 && key > node->left->key)
	{	
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}

	// Right Left Case
	if (balance < -1 && key < node->right->key)
	{
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}

	/* return the (unchanged) node pointer */
	return node;
}
/*--------------------------------------------------------------------------------------*/

void insertUserNode(USER* st, USER* temp)
{
	//printf("\n%ld\n",temp->phone_no);
	if((st->phone_no)  > (temp->phone_no))
	{
		if (st->left == NULL)
			st->left = temp;
		else
			insertUserNode(st->left, temp);
	}
	else
	{
		if (st->right == NULL)
			st->right = temp;
		else
			insertUserNode(st->right, temp);
	}
	st->height = 1 + max(NodeHeight(st->left), NodeHeight(st->right));
	
	int balance = BalanceFactor(st);

	if( balance > 1 && (temp->phone_no < st->left->phone_no) )
	{
		st = performLLRotation(st);
	}
	else if( balance > 1 && (temp->phone_no > st->left->phone_no) )
    {
		st = performLRRotation(st);
	}
	else if( balance < -1 && (temp->phone_no > st->right->phone_no) )
	{
		st = performRRRotation(st);
	}
	else if( balance < -1 && (temp->phone_no < st->right->phone_no) )
	{
		st = performRLRotation(st);
	}
	//return temp;
}
/*--------------------------------------------------------------------------------------*/
int BalanceFactor(USER * temp)
{
	if (temp == NULL)
		return 0;
	return NodeHeight(temp->left) - NodeHeight(temp->right);
}
/*--------------------------------------------------------------------------------------*/
int NodeHeight( USER * temp )
{
	if (temp == NULL)	
		return 0;
	return temp->height;
}
/*--------------------------------------------------------------------------------------*/
int max(int a, int b)
{
	return a > b ? a : b ;
}
/*--------------------------------------------------------------------------------------*/
USER * performLLRotation(USER * temp)
{
	USER * p = temp->left ;
	USER * q = p->right ;
	p->right = temp ;
	temp->left = q ;

	temp->height =  1 + max(NodeHeight(temp->left), NodeHeight(temp->right));;
	p->height = 1 + max(NodeHeight(p->left), NodeHeight(p->right)); 

	if( root = temp )
		root = p ;

	return p ;
}
/*--------------------------------------------------------------------------------------*/
USER * performRLRotation(USER * temp)
{
	printf("\n\t\t%lld\n",temp->phone_no);
	USER* p = temp->right;
	USER* c = p->left;
	USER* l = c->left;
	USER* r = c->right;
	c->left = temp;
	c->right = p ;
	p->left = r ;
	temp->right = l ;

	p->height = 1 + max(NodeHeight(p->left), NodeHeight(p->right));
	c->height = 1 + max(NodeHeight(c->left), NodeHeight(c->right));
	temp->height = 1 + max(NodeHeight(temp->left), NodeHeight(temp->right));

	if(root == temp)
		root = c ;
	
	return c ;	
}
/*--------------------------------------------------------------------------------------*/
USER * performLRRotation(USER * temp)
{
	printf("\n\t\t%lld\n",temp->phone_no);
	USER* p = temp->left ;
	USER* c = p->right;
	USER* l = c->left;
	USER* r = c->right;
	c->left = p;
	c->right = temp ;
	temp->left = r ;
	p->right = l;

	p->height = 1 + max(NodeHeight(p->left), NodeHeight(p->right));
	c->height = 1 + max(NodeHeight(c->left), NodeHeight(c->right));
	temp->height = 1 + max(NodeHeight(temp->left), NodeHeight(temp->right));

	if(root == temp)
		root = c ;
	
	return c ;
}
/*--------------------------------------------------------------------------------------*/
USER * performRRRotation(USER * temp)
{
	printf("\n\t\t%lld\n",temp->phone_no);
	USER * p = temp->right ;
	USER * q = p->left ;
	p -> left = temp ;
	temp->right = q ;

	temp->height = 1 + max(NodeHeight(temp->left), NodeHeight(temp->right));
	p->height = 1 + max(NodeHeight(p->left), NodeHeight(p->right));

	if(temp == root)
		root = p ;

	return p ;
}
/*--------------------------------------------------------------------------------------*/
void preorderUser(USER * head)
{
	if(head == NULL)
	{
		return;
	}
	printf("%lld\t",head->phone_no);
	preorderUser(head -> left);
	preorderUser(head -> right);
}
/*--------------------------------------------------------------------------------------*/
int main()
{
	createUserTree();
	preorderUser(root);
	return 0 ;
}
/*--------------------------------------------------------------------------------------*/
