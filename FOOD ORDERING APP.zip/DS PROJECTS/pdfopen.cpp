#include<bits/stdc++.h>
using namespace std ; 

int main()
{
	FILE * pt = fopen("D:\\TEMPORARY\\7977202306042000081660.pdf","r+");
	fclose(pt);
	return 0 ;
}