#include<iostream>
#include<bits/stdc++.h>
using namespace std ;
int main()
{
	string str ; 
	cin >> str ; 
	stack<char>s ;
	vector<char> v ;
	for( int i = 0 ; i < str.length() ; i++ )
	{
		
	}
	return 0 ;
}
 // aabbbaa --> 2
// Abcdcbca
// aabbccaa --- > abcba
/*
a
b
c
d
*/