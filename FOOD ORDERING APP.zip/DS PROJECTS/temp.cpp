#include<iostream>
#include<bits/stdc++.h>
using namespace std;

int min(int a , int b , int c );
int main() 
{
	// your code goes here
	int T, A;
	//auto it ;
	cin >> T ;
	while( T-- )
	{
		int m1,m2 ;
		set<int> s1 , s2;
	   // int ans = min(A,B,C);
	   // //cout << ans << endl ;
	   // if(ans == 1)
	   //    m1 = B + C ;
	   // else if ( ans == 2 )
	   //     m1 = A + C ;
	   // else 
	   //     m1 = A + B ;

	   // cin >> A >> B >> C;
	   // ans = min(A,B,C);
	   // //cout << ans << endl ;
	   // if(ans == 1)
	   //    m2 = B + C ;
	   // else if ( ans == 2 )
	   //     m2 = A + C ;
	   // else 
	   //     m2 = B + A ;
    //     if( m1 > m2 )
    //         cout << "Alice" << endl ;
    //     else if( m2 > m1 )
    //         cout << "Bob" << endl ;
    //     else 
    //         cout << "Tie" << endl ;
        for( int i = 0 ; i < 3 ; i++ )
        {
            cin >> A ;
            s1.insert(A);
        }
        auto it = s1.begin() ;
        m1 = (*it+2) + (*it+1) ;
        for( int i = 0 ; i < 3 ; i++ )
        {
            cin >> A ;
            s2.insert(A);
        }
        it = s2.begin() ;
        m2 = (*it+2) + (*it+1) ;
        if( m1 > m2 )
            cout << "Alice" << endl   ;
        else if( m2 > m1 )
            cout << "Bob" << endl ;
        else 
            cout << "Tie" << endl ;
	}; 
	return 0;
}


int min(int a , int b , int c )
{
    if( a <= b  && b <= c )
        return 1 ;
    else if( b <= c && b <= a )
        return 2 ;
    return 3 ;
}









#include<iostream>
#include<bits/stdc++.h>
using namespace std;

int min(int a , int b , int c );
int main() {
	// your code goes here
	int T, A, B , C ;
	//auto it ;
	cin >> T ;
	while( T-- )
	{
		int m1,m2 ;
		cin >> A >> B >> C ;
		int ans = min(A,B,C);
	    //cout << ans << endl ;
		if(ans == 1)
			m1 = B + C ;
		else if ( ans == 2 )
			m1 = A + C ;
		else 
			m1 = A + B ;

		cin >> A >> B >> C;
		ans = min(A,B,C);
		//cout << ans << endl ;
		if(ans == 1)
			m2 = B + C ;
		else if ( ans == 2 )
			m2 = A + C ;
		else 
			m2 = B + A ;
        if( m1 > m2 )
            cout << "Alice" << endl ;
        else if( m2 > m1 )
            cout << "Bob" << endl ;
        else 
            cout << "Tie" << endl ;
	}; 
	return 0;
}


int min(int a , int b , int c )
{
    if( a <= b  && b <= c )
        return 1 ;
    else if( b <= c && b <= a )
        return 2 ;
    else if (c <= b && c <= a )
        return 3 ;
}